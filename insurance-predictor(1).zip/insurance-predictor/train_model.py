"""
Objectives 1-6 from the project deck:
  load -> clean -> EDA -> train 3 regressors -> evaluate (MAE, RMSE, R2) -> save best.
"""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeRegressor

NUMERIC = ["age", "bmi", "children"]
CATEGORICAL = ["sex", "smoker", "region"]
TARGET = "charges"

# ---------- 1-2. Load and preprocess ----------
df = pd.read_csv("data/insurance.csv")
rows_before = len(df)
df = df.drop_duplicates()
df = df.dropna(subset=[TARGET])
for col in NUMERIC:
    df[col] = pd.to_numeric(df[col], errors="coerce")
    df[col] = df[col].fillna(df[col].median())
for col in CATEGORICAL:
    df[col] = df[col].astype(str).str.strip().str.lower()
    df[col] = df[col].replace("nan", df[col].mode()[0])
print(f"Cleaned: {rows_before} -> {len(df)} rows")

# ---------- 3. EDA ----------
encoded = df.copy()
encoded["smoker"] = (encoded["smoker"] == "yes").astype(int)
encoded["sex"] = (encoded["sex"] == "male").astype(int)
corr = encoded[["age", "sex", "bmi", "children", "smoker", TARGET]].corr()[TARGET].drop(TARGET)
eda = {
    "rows": int(len(df)),
    "avg_charge": round(float(df[TARGET].mean()), 2),
    "smoker_avg": round(float(df[df.smoker == "yes"][TARGET].mean()), 2),
    "non_smoker_avg": round(float(df[df.smoker == "no"][TARGET].mean()), 2),
    "correlation": {k: round(float(v), 3) for k, v in corr.sort_values(ascending=False).items()},
    "by_region": {k: round(float(v), 2) for k, v in df.groupby("region")[TARGET].mean().items()},
}

# ---------- 4. Train and compare ----------
X, y = df[NUMERIC + CATEGORICAL], df[TARGET]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

prep = ColumnTransformer([
    ("num", StandardScaler(), NUMERIC),
    ("cat", OneHotEncoder(handle_unknown="ignore", drop="if_binary"), CATEGORICAL),
])
candidates = {
    "Linear Regression": LinearRegression(),
    "Decision Tree": DecisionTreeRegressor(max_depth=5, min_samples_leaf=10, random_state=42),
    "Random Forest": RandomForestRegressor(n_estimators=300, max_depth=8,
                                           min_samples_leaf=5, random_state=42, n_jobs=-1),
}

# ---------- 5. Evaluate ----------
results, fitted = [], {}
for name, reg in candidates.items():
    pipe = Pipeline([("prep", prep), ("model", reg)]).fit(X_train, y_train)
    pred = pipe.predict(X_test)
    results.append({
        "model": name,
        "mae": round(float(mean_absolute_error(y_test, pred)), 2),
        "rmse": round(float(np.sqrt(mean_squared_error(y_test, pred))), 2),
        "r2": round(float(r2_score(y_test, pred)), 4),
    })
    fitted[name] = (pipe, pred)
    print(f"{name:18s} MAE={results[-1]['mae']:>9} RMSE={results[-1]['rmse']:>9} R2={results[-1]['r2']}")

best = max(results, key=lambda r: r["r2"])["model"]
print("Best model:", best)

# ---------- 6. Save for the web app ----------
best_pipe, best_pred = fitted[best]
residual_std = float(np.std(y_test - best_pred))
joblib.dump(best_pipe, "model/best_model.joblib")
json.dump({
    "best_model": best,
    "results": results,
    "residual_std": round(residual_std, 2),
    "eda": eda,
    "baseline": {  # used by the "what drives this estimate" breakdown
        "age": float(df.age.median()), "bmi": float(df.bmi.median()),
        "children": 0, "sex": df.sex.mode()[0], "smoker": "no",
        "region": df.region.mode()[0],
    },
}, open("model/metrics.json", "w"), indent=2)
print("Saved model/best_model.joblib and model/metrics.json")
