# Medical Insurance Cost Predictor

Python (scikit-learn + Flask) backend with an HTML/CSS/JavaScript frontend.
Built from the project deck: clean data, explore it, compare Linear Regression,
Decision Tree and Random Forest, evaluate with MAE / RMSE / R², then predict
costs for new people.

## Run it

```bash
pip install -r requirements.txt
python generate_data.py     # skip if you add the real Kaggle insurance.csv to data/
python train_model.py       # trains and compares the 3 models, saves the best one
python app.py               # open http://127.0.0.1:5000
```

## Use the real dataset

Download "Medical Cost Personal Dataset" (insurance.csv) from Kaggle, place it at
`data/insurance.csv`, then run `python train_model.py` again. Columns needed:
age, sex, bmi, children, smoker, region, charges.

## Structure

| File | Role |
|---|---|
| `generate_data.py` | Makes a synthetic insurance.csv so the project runs out of the box |
| `train_model.py` | Preprocessing, EDA, model training, MAE/RMSE/R², saves best model |
| `app.py` | Flask server: `/`, `POST /api/predict`, `GET /api/metrics` |
| `templates/index.html` | Page layout |
| `static/style.css`, `static/script.js` | Styling and live prediction logic |

## Ideas to extend it

- Add a Gradient Boosting or XGBoost model to the comparison
- Add EDA charts (charges by age, BMI vs charges) with Chart.js
- Add cross-validation and hyperparameter tuning with GridSearchCV
- Deploy on Render or Railway
