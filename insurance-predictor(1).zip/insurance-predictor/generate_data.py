"""
Creates data/insurance.csv with the same columns as the Kaggle
"Medical Cost Personal Dataset" (age, sex, bmi, children, smoker, region, charges).

It is synthetic, so the app runs out of the box. To use the real data,
download insurance.csv from Kaggle and overwrite data/insurance.csv.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
n = 1338

age = rng.integers(18, 65, n)
sex = rng.choice(["male", "female"], n)
bmi = np.clip(rng.normal(30.6, 6.1, n), 15.9, 53.1).round(2)
children = rng.choice([0, 1, 2, 3, 4, 5], n, p=[0.43, 0.24, 0.18, 0.12, 0.02, 0.01])
smoker = rng.choice(["yes", "no"], n, p=[0.2, 0.8])
region = rng.choice(["southwest", "southeast", "northwest", "northeast"], n)

charges = (
    2500
    + 260 * (age - 18)
    + 14 * (age - 18) ** 1.5
    + 380 * np.maximum(bmi - 25, 0)
    + 480 * children
    + np.where(smoker == "yes", 14000 + 420 * np.maximum(bmi - 30, 0) * 8, 0)
    + np.where(region == "southeast", 600, 0)
    + np.where(sex == "male", 180, 0)
)
charges = np.maximum(1200, charges * rng.lognormal(0, 0.18, n)).round(2)

df = pd.DataFrame(dict(age=age, sex=sex, bmi=bmi, children=children,
                       smoker=smoker, region=region, charges=charges))
df.to_csv("data/insurance.csv", index=False)
print(f"Wrote data/insurance.csv with {len(df)} rows")
