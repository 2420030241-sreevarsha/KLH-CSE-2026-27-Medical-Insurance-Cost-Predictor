import json
import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
model = joblib.load("model/best_model.joblib")
meta = json.load(open("model/metrics.json"))

FIELDS = ["age", "sex", "bmi", "children", "smoker", "region"]


def validate(data):
    """Return (clean_dict, error_message)."""
    try:
        row = {
            "age": int(data["age"]),
            "sex": str(data["sex"]).lower(),
            "bmi": float(data["bmi"]),
            "children": int(data["children"]),
            "smoker": str(data["smoker"]).lower(),
            "region": str(data["region"]).lower(),
        }
    except (KeyError, ValueError, TypeError):
        return None, "Fill in every field with a valid value."
    if not 18 <= row["age"] <= 100:
        return None, "Age must be between 18 and 100."
    if not 10 <= row["bmi"] <= 60:
        return None, "BMI must be between 10 and 60."
    if not 0 <= row["children"] <= 10:
        return None, "Dependents must be between 0 and 10."
    if row["sex"] not in ("male", "female") or row["smoker"] not in ("yes", "no"):
        return None, "Choose a valid option for sex and smoking status."
    if row["region"] not in ("northeast", "northwest", "southeast", "southwest"):
        return None, "Choose a valid region."
    return row, None


def predict_one(row):
    return float(model.predict(pd.DataFrame([row]))[0])


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/predict", methods=["POST"])
def predict():
    row, err = validate(request.get_json(silent=True) or {})
    if err:
        return jsonify(error=err), 400

    estimate = predict_one(row)
    margin = 1.0 * meta["residual_std"]

    # What-if breakdown: how much does each input move the estimate
    # compared with a baseline person (median age/BMI, no kids, non-smoker)?
    base_row = dict(meta["baseline"])
    base_cost = predict_one(base_row)
    drivers = []
    for f in FIELDS:
        alt = dict(base_row)
        alt[f] = row[f]
        drivers.append({"factor": f, "impact": round(predict_one(alt) - base_cost, 2)})
    drivers.sort(key=lambda d: abs(d["impact"]), reverse=True)

    return jsonify(
        estimate=round(estimate, 2),
        low=round(max(0, estimate - margin), 2),
        high=round(estimate + margin, 2),
        baseline=round(base_cost, 2),
        drivers=drivers,
        model=meta["best_model"],
    )


@app.route("/api/metrics")
def metrics():
    return jsonify(best_model=meta["best_model"], results=meta["results"], eda=meta["eda"])


if __name__ == "__main__":
    app.run(debug=True)
