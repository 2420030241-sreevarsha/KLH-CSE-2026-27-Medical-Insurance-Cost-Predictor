const $ = (id) => document.getElementById(id);
const form = $("form");
const money = (n) => "$" + Math.round(n).toLocaleString("en-US");
const signed = (n) => (n >= 0 ? "+" : "\u2212") + money(Math.abs(n));
const LABELS = { age: "Age", bmi: "BMI", children: "Dependents", sex: "Sex", smoker: "Smoking", region: "Region" };

function bmiClass(b) {
  if (b < 18.5) return "Underweight";
  if (b < 25) return "Healthy";
  if (b < 30) return "Overweight";
  return "Obese";
}

function readForm() {
  return Object.fromEntries(new FormData(form).entries());
}

function syncOutputs() {
  $("age-out").textContent = $("age").value;
  $("bmi-out").textContent = Number($("bmi").value).toFixed(1);
  $("bmi-class").textContent = "(" + bmiClass(Number($("bmi").value)) + ")";
}

function showError(msg) {
  $("error").textContent = msg || "";
  $("error").hidden = !msg;
}

async function predict() {
  showError("");
  try {
    const res = await fetch("/api/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(readForm()),
    });
    const data = await res.json();
    if (!res.ok) return showError(data.error);
    render(data);
  } catch {
    showError("Can't reach the server. Check that app.py is running.");
  }
}

function render(d) {
  $("figure").textContent = money(d.estimate);
  $("low").textContent = money(d.low);
  $("high").textContent = money(d.high);
  $("model-name").textContent = d.model;
  $("range").hidden = false;

  const span = d.high - d.low;
  const lo = d.low - span * 0.25, hi = d.high + span * 0.25;
  const pct = (v) => ((v - lo) / (hi - lo)) * 100;
  $("range-fill").style.left = pct(d.low) + "%";
  $("range-fill").style.width = pct(d.high) - pct(d.low) + "%";
  $("range-dot").style.left = pct(d.estimate) + "%";

  const maxImpact = Math.max(...d.drivers.map((x) => Math.abs(x.impact)), 1);
  $("drivers").innerHTML = d.drivers.map((x) => {
    const w = (Math.abs(x.impact) / maxImpact) * 50;
    const dir = x.impact >= 0 ? "up" : "down";
    return `<li><span>${LABELS[x.factor]}</span>
      <span class="track"><span class="bar ${dir}" style="width:${w}%"></span></span>
      <span class="amt">${signed(x.impact)}</span></li>`;
  }).join("");
}

async function loadMetrics() {
  const res = await fetch("/api/metrics");
  const m = await res.json();
  const e = m.eda;
  const ratio = (e.smoker_avg / e.non_smoker_avg).toFixed(1);
  $("eda").innerHTML = `
    <div><strong>${ratio}&times;</strong><span>Smokers are charged about ${ratio} times more than non-smokers on average</span></div>
    <div><strong>${money(e.avg_charge)}</strong><span>Average yearly charge across ${e.rows.toLocaleString()} records</span></div>
    <div><strong>${e.correlation.smoker.toFixed(2)}</strong><span>Correlation of smoking with charges, the strongest of any single factor</span></div>`;
}

let timer;
form.addEventListener("input", () => {
  syncOutputs();
  clearTimeout(timer);
  timer = setTimeout(predict, 250);
});
form.addEventListener("submit", (e) => { e.preventDefault(); predict(); });

syncOutputs();
loadMetrics();
predict();
